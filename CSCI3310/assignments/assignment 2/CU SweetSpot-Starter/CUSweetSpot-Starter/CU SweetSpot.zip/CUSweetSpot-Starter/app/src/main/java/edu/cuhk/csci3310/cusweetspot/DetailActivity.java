package edu.cuhk.csci3310.cusweetspot;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    private static final String TAG = "DetailActivity";
    private ImageView mImageView;
    private EditText mEditName;
    private TextView mTextCULoc;
    private Button mButtonDec, mButtonInc;
    private TextView mTextRating;
    private Button mButtonSave, mButtonCancel;

    private String sharedPrefFile = "sweetsharedprefs";
    private  int mPosition;
    String[] mInitSweetInfoStr = new String[3];
    String[] mUpdatedSweetInfoStr = new String[3];
    private String mPositionStr = "";
    private String mInitSweetName = "";
    private String mSweetName = "";
    private String mInitGenus = "";
    //private String[] mRichnessStr = {"Scattered", "Clustered", "Hill-full"};
    private int mInitRating = 3, mRating;
    private final String mDrawableFilePath = "android.resource://edu.cuhk.csci3310.cusweetspot/drawable/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Bundle extras = getIntent().getExtras(); // another way to get extras as bundle from intent
        //String positionStr = extras.getString("position");
        Intent intent = getIntent();
        mPositionStr = intent.getStringExtra("position"); // knowing which position

        for(int i=0; i<2; i++) {
            mInitSweetInfoStr[i] = intent.getStringExtra("info" + i);
            mUpdatedSweetInfoStr[i] = mInitSweetInfoStr[i];
        }

        Log.v( TAG, "Entry position: "    + mPositionStr);
        Log.v( TAG, "Sweet Name: "   + mInitSweetInfoStr[0]);
        Log.v( TAG, "Location"   + mInitSweetInfoStr[1]);

        try {
            mPosition = Integer.valueOf(mPositionStr);
        } catch (Exception e) {
            mPosition = 0;
        }
        String mImagePath = MainActivity.mImagePathList.get(mPosition);
        Uri uri = Uri.parse(mImagePath);
        mImageView = (ImageView) findViewById(R.id.image_large);
        mImageView.setImageURI(uri);
        mEditName = (EditText) findViewById(R.id.edit_name);
        mTextCULoc = (TextView) findViewById(R.id.link_cu_map);
        mTextRating = (TextView) findViewById(R.id.value_rating);

        SharedPreferences mPrefs=getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        if(mPrefs != null) {
            mRating = mPrefs.getInt("rating" + mPosition, 3);
            mSweetName = mPrefs.getString("name"+mPosition, mInitSweetInfoStr[0]);
        }
        else {
            mRating = mInitRating = 3;
            mSweetName = mInitSweetInfoStr[0];
        }
        mTextRating.setText(""+mRating);

        mEditName.setText(mSweetName);
        mTextCULoc.setText(mInitSweetInfoStr[1]);

        mTextCULoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String URL = "https://www.openrice.com/en/hongkong/restaurants?what=";
                String restoStr = mInitSweetInfoStr[1].replace(" ", "%20");
                // Prepare an implicit intent to bring user to the CU Map page
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(URL+restoStr));
                v.getContext().startActivity(browserIntent);
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences mPrefs=getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        SharedPreferences.Editor ed=mPrefs.edit();
        mSweetName = String.valueOf(mEditName.getText());
        ed.putString("name"+mPosition, mSweetName);
        ed.putInt("rating"+mPosition, mRating);
        ed.commit();
    }

    public void plusRating(View view) {
        mRating = mRating==5?5:mRating+1;
        mTextRating.setText(""+mRating);
    }

    public void minusRating(View view) {
        mRating = mRating==0?0:mRating-1;
        mTextRating.setText(""+mRating);
    }

}