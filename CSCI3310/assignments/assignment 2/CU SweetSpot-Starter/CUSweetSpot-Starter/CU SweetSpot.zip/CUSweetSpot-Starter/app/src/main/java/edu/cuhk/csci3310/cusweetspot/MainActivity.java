package edu.cuhk.csci3310.cusweetspot;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;

import java.io.File;
import java.io.InputStream;
import java.util.LinkedList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private RecyclerView mRecyclerView;
    private SweetListAdapter mAdapter;
    static LinkedList<String> mImagePathList = new LinkedList<>();
    static LinkedList<String[]> mSweetInfoList = new LinkedList<>();

    //final String mRawFilePath = "android.resource://edu.cuhk.csci3310.cusweetspot/raw/";
    final String mAppFilePath = "/data/data/edu.cuhk.csci3310.cusweetspot/";
    final String mDrawableFilePath = "android.resource://edu.cuhk.csci3310.cusweetspot/drawable/";

    // ... Rest of MainActivity code ...
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String baseDir;
        baseDir = mAppFilePath;
        String filePath = baseDir + File.separator + "cu_sweeties_updated.csv";
        File localFile = new File(filePath);

        boolean exists = localFile.exists();

        readCSV("cu_sweeties.csv", true);
        
        // Put initial data into the image list.
        for (int i = 1; i <= 10; i++) {
            mImagePathList.addLast(mDrawableFilePath + "image" + String.format("%02d",i));
        }
        // Get a handle to the RecyclerView.
        mRecyclerView = findViewById(R.id.recyclerview);
        // Create an adapter and supply the data to be displayed.
        mAdapter = new SweetListAdapter(this, mSweetInfoList);
        // Connect the adapter with the RecyclerView.
        mRecyclerView.setAdapter(mAdapter);
        // Give the RecyclerView a default layout manager.
        int num_col=2;

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            num_col = 3;
        } else if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            num_col = 2;
        }
        //mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setLayoutManager(new GridLayoutManager(this, num_col));

    }

    private void readCSV(String fileName, boolean isFromRes) {
        Scanner fileIn;
        String baseDir;
        baseDir = mAppFilePath;

        String filePath = baseDir + File.separator + fileName;
        File localFile = new File(filePath);
        Log.v( TAG, "Reading CSV from: " + filePath);

        // debug: initially read from /res/raw instead of /data/data/<Package>/files
        InputStream rcFile = this.getResources().openRawResource(R.raw.cu_sweeties);

        mSweetInfoList.clear(); // ensure prior save didn't mess up
        try {
            if(isFromRes)
                fileIn = new Scanner(rcFile); // for initial setup
            else
                fileIn = new Scanner(localFile);
            String row;
            int j = 0;
            while (fileIn.hasNextLine()) {
                row = fileIn.nextLine();
                String[] data = row.split(",");
                // do something with the data
                if (j++ != 0) mSweetInfoList.addLast(data);
            }
        } catch (Exception e) { // must catch potential IOException in folder File reading
            Log.e(TAG, "readCSV failed: " + e.getMessage()); }

    } // readCSV


}
