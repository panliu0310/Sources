package edu.cuhk.csci3310.cusweetspot;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.LinkedList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

public class SweetListAdapter extends Adapter<SweetListAdapter.SweetViewHolder>  {
    private static final String TAG = "SweetListAdapter";
    private Context context;
    private LayoutInflater mInflater;

    private LinkedList<String[]> mSweetInfoList;

    // the following pre-set res image path is for debugging, but good to let students to start with
    private String mDrawableFilePath = "android.resource://edu.cuhk.csci3310.cusweetspot/drawable/";

    public Integer[] imageIds = {
            R.drawable.image01,
            R.drawable.image02,
            R.drawable.image03,
            R.drawable.image04,
            R.drawable.image05,
            R.drawable.image06,
            R.drawable.image07,
            R.drawable.image08,
            R.drawable.image09,
            R.drawable.image10
    };

    class SweetViewHolder extends RecyclerView.ViewHolder {

        public ImageView imageItemView;
        public TextView nameTextView, locTextView, wikiTextView;
        public RatingBar flowerRichnessBar;
        final SweetListAdapter mAdapter;

        public SweetViewHolder(View itemView, SweetListAdapter adapter) {
            super(itemView);
            imageItemView = itemView.findViewById(R.id.image);
            this.mAdapter = adapter;

            imageItemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Get the position of the item that was clicked.
                    int mPosition = getLayoutPosition();

                    // Prepare an explicit intent to bring user to another DetailActivity for editing
                    Intent expIntent = new Intent(v.getContext().getApplicationContext(), DetailActivity.class);
                    expIntent.putExtra("position", Integer.toString(mPosition));

                    for(int i=0; i < 2; i++) {
                        expIntent.putExtra("info" + i, mSweetInfoList.get(mPosition)[i + 1]);
                    }
                    v.getContext().startActivity(expIntent);
                }
            });
        }

    }

    public SweetListAdapter(Context context,
                            LinkedList<String[]> sweetInfoList) {
        mInflater = LayoutInflater.from(context);
        this.mSweetInfoList = sweetInfoList;
    }

    @NonNull
    @Override
    public SweetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mItemView = mInflater.inflate(R.layout.imagelist_item, parent, false);
        return new SweetViewHolder(mItemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull SweetViewHolder holder, int position) {
        String[] mSweetInfo = mSweetInfoList.get(position);

        // trim the ending .jpg first before setting the ImageView
        String[] imageFilename = mSweetInfo[0].split(".");
        Uri uri = Uri.parse(mDrawableFilePath+mSweetInfo[0].substring(0, mSweetInfo[0].lastIndexOf('.')));
        holder.imageItemView.setImageURI(uri);
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mSweetInfoList.size();
    }

    public void updateData(LinkedList<String[]> sweetInfoList) {
        this.mSweetInfoList = sweetInfoList;
        // Notify the adapter, that the data has changed so it can
        // update the RecyclerView to display the data.
        notifyDataSetChanged();
    }
}